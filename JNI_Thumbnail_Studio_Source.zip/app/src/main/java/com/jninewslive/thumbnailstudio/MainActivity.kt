package com.jninewslive.thumbnailstudio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen() {
    val context = LocalContext.current
    var headline by remember { mutableStateOf("सिकंदराबाद में बड़ी खबर") }
    var subhead by remember { mutableStateOf("पूरी खबर पढ़ें JNI News Live पर") }
    var format by remember { mutableStateOf("16:9") }
    var mode by remember { mutableStateOf("मैनुअल एडिटर") }
    var imageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var tag by remember { mutableStateOf("BREAKING NEWS") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                imageBitmap = BitmapFactory.decodeStream(stream)
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = ComposeColor(0xFFE31E24),
        background = ComposeColor(0xFF10151F),
        surface = ComposeColor(0xFF1B2432)
    )) {
        Scaffold(containerColor = ComposeColor(0xFF10151F)) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.jni_news_live_logo),
                        contentDescription = "JNI News Live Logo",
                        modifier = Modifier.size(64.dp),
                        contentScale = ContentScale.Fit
                    )
                    Column {
                        Text("JNI NEWS LIVE", color = ComposeColor.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Text("THUMBNAIL STUDIO", color = ComposeColor(0xFFFFC928), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Text("नया न्यूज़ थंबनेल बनाएं", color = ComposeColor.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("16:9", "9:16").forEach { item ->
                        FilterChip(selected = format == item, onClick = { format = item }, label = { Text(if (item == "16:9") "YouTube 16:9" else "Reels 9:16") })
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = mode == "मैनुअल एडिटर", onClick = { mode = "मैनुअल एडिटर" }, label = { Text("Manual Editor") })
                    FilterChip(selected = mode == "AI डिजाइन", onClick = { mode = "AI डिजाइन" }, label = { Text("AI Design") })
                }

                OutlinedButton(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.AddPhotoAlternate, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (imageBitmap == null) "न्यूज़ फोटो अपलोड करें" else "फोटो बदलें")
                }

                OutlinedTextField(value = headline, onValueChange = { headline = it }, label = { Text("मुख्य हेडलाइन") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(value = subhead, onValueChange = { subhead = it }, label = { Text("सब हेडलाइन") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("ऊपर का टैग") }, modifier = Modifier.fillMaxWidth())

                Text("प्रीव्यू", color = ComposeColor.White, fontWeight = FontWeight.Bold)
                ThumbnailPreview(imageBitmap, headline, subhead, tag, format)

                Button(
                    onClick = {
                        try {
                            val out = renderThumbnail(imageBitmap, headline, subhead, tag, format)
                            val name = "JNI_Thumbnail_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.png"
                            val values = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JNI News Live")
                            }
                            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            if (uri != null) context.contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            Toast.makeText(context, "थंबनेल गैलरी में सेव हो गया", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "सेव नहीं हो पाया: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Download, null)
                    Spacer(Modifier.width(8.dp))
                    Text("HD PNG डाउनलोड / गैलरी में सेव")
                }

                if (mode == "AI डिजाइन") {
                    Card(colors = CardDefaults.cardColors(containerColor = ComposeColor(0xFF332B18))) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = ComposeColor(0xFFFFC928))
                            Spacer(Modifier.width(8.dp))
                            Text("AI जनरेशन के लिए सुरक्षित बैकएंड और API कनेक्शन जोड़ना बाकी है। API key ऐप में सीधे नहीं रखी जाएगी।", color = ComposeColor.White, fontSize = 13.sp)
                        }
                    }
                }
                Text("नोट: मूल अपलोड फोटो को बिना फेस रीजनरेशन के उपयोग किया जाता है। यह शुरुआती प्रोजेक्ट है; AI इमेज जनरेशन और उन्नत लेयर एडिटर अगले विकास चरण में जोड़े जाएंगे।", color = ComposeColor(0xFFB7C0CE), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun ThumbnailPreview(bitmap: Bitmap?, headline: String, subhead: String, tag: String, format: String) {
    val ratio = if (format == "16:9") 16f / 9f else 9f / 16f
    Box(
        Modifier.fillMaxWidth().aspectRatio(ratio).clip(RoundedCornerShape(12.dp))
            .background(ComposeColor(0xFF252D3A)).border(1.dp, ComposeColor(0xFF536174), RoundedCornerShape(12.dp))
    ) {
        if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(ComposeColor(0x99000000)))
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(tag.uppercase(), color = ComposeColor.White, fontSize = 11.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.background(ComposeColor(0xFFE31E24), RoundedCornerShape(3.dp)).padding(horizontal = 7.dp, vertical = 4.dp))
            Text(headline, color = ComposeColor.White, fontSize = if (format == "16:9") 24.sp else 27.sp, lineHeight = 30.sp, fontWeight = FontWeight.Black)
            Text(subhead, color = ComposeColor(0xFFFFD447), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("JNI NEWS LIVE", color = ComposeColor.White, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

fun renderThumbnail(source: Bitmap?, headline: String, subhead: String, tag: String, format: String): Bitmap {
    val w = if (format == "16:9") 1920 else 1080
    val h = if (format == "16:9") 1080 else 1920
    val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(result)
    canvas.drawColor(Color.rgb(27, 35, 49))
    if (source != null) {
        val src = Rect(0, 0, source.width, source.height)
        val scale = maxOf(w.toFloat()/source.width, h.toFloat()/source.height)
        val sw = (w/scale).toInt().coerceAtMost(source.width)
        val sh = (h/scale).toInt().coerceAtMost(source.height)
        val sx = (source.width-sw)/2
        val sy = (source.height-sh)/2
        canvas.drawBitmap(source, Rect(sx, sy, sx+sw, sy+sh), Rect(0,0,w,h), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }
    val overlay = Paint().apply { color = Color.argb(175, 0, 0, 0) }
    canvas.drawRect(0f, h*0.55f, w.toFloat(), h.toFloat(), overlay)
    val left = w*0.055f
    var y = h*0.69f
    val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(227,30,36); textSize = h*0.035f; typeface = android.graphics.Typeface.create("sans-serif-black", 1) }
    canvas.drawRect(left, y-h*0.055f, left+w*0.40f, y+h*0.005f, Paint().apply { color = Color.rgb(227,30,36) })
    canvas.drawText(tag.take(28).uppercase(), left+w*0.012f, y-h*0.012f, tagPaint)
    val headlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = if (format=="16:9") h*0.09f else h*0.065f
        typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
        setShadowLayer(5f, 2f, 2f, Color.BLACK)
    }
    val maxWidth = w*0.88f
    val lines = wrapText(headline, headlinePaint, maxWidth)
    y += h*0.07f
    lines.take(if (format=="16:9") 2 else 4).forEach { line ->
        canvas.drawText(line, left, y, headlinePaint); y += headlinePaint.textSize*1.12f
    }
    val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255,211,61); textSize = h*0.035f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
    canvas.drawText(subhead.take(90), left, (h*0.92f).coerceAtMost(y+h*0.05f), subPaint)
    val brandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = h*0.025f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
    canvas.drawText("JNI NEWS LIVE", left, h*0.975f, brandPaint)
    return result
}

fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
    val words = text.trim().split(Regex("\\s+"))
    val lines = mutableListOf<String>()
    var line = ""
    for (word in words) {
        val candidate = if (line.isEmpty()) word else "$line $word"
        if (paint.measureText(candidate) <= maxWidth || line.isEmpty()) line = candidate
        else { lines.add(line); line = word }
    }
    if (line.isNotEmpty()) lines.add(line)
    return lines
}
