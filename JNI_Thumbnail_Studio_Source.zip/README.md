# JNI Thumbnail Studio — Android source project

This is a starter Android Studio project for JNI News Live.

## Included now
- Native Android app UI (Jetpack Compose)
- 16:9 YouTube and 9:16 Reels/Shorts formats
- Photo picker
- Editable Hindi headline, subheadline and breaking tag
- Thumbnail preview
- PNG export to Pictures/JNI News Live
- Original uploaded image is used directly; no face regeneration is performed

## Important limitations in this starter
- AI image generation is not connected yet. The AI mode currently displays a setup notice.
- Advanced layer editing, multiple-photo composition, custom font selection, saved templates, logo upload and cloud sync are planned follow-up features.
- Face preservation here means the uploaded photo is not sent through a face-generating model. Cropping/resizing for the canvas can change framing, not facial identity.
- The PNG renderer uses Android's default sans-serif typeface. For production-quality Devanagari typography, bundle and license a Devanagari font such as Noto Sans Devanagari and use it in the renderer.

## Build APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

Command-line build (after installing Android SDK and Gradle):
`gradle assembleDebug`

## AI backend integration (required before production)
Do not put an AI provider API key in the Android app. Create a HTTPS backend endpoint and have the app send:
- uploaded image
- headline and subheadline
- target aspect ratio
- style/template selection

The backend should return a generated background/layout or a composited image. Preserve the uploaded original person photo as a separate, unmodified foreground layer. Keep the API key only on the backend.

## Package
`com.jninewslive.thumbnailstudio`
\n\n## Supplied brand asset\n- Added the user-provided JNI News Live logo as `app/src/main/res/drawable-nodpi/jni_news_live_logo.png` and displayed it in the app header without altering the artwork.\n